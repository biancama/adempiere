create function unaccent_string(text, numeric) returns text
LANGUAGE plpgsql
AS $$
DECLARE
    input_string text := $1;
    output_string text;
    version numeric := $2;
BEGIN

input_string := translate(input_string, 'âaaaaaÁÂAAAAAA', 'aaaaaaaaaaaaaa');
input_string := translate(input_string, 'eééeëeeeeeEËEEE', 'eeeeeeeeeeeeeee');
input_string := translate(input_string, 'iíîiiiiïÏÍÎIIIII', 'iiiiiiiiiiiiiiii');
input_string := translate(input_string, 'óôooooOÓÔOOOOO', 'oooooooooooooo');
input_string := translate(input_string, 'uúuuuuuUÚUUUUUU', 'uuuuuuuuuuuuuuu');
input_string := translate(input_string, 'ç', 'c');
if version = 1 then
 input_string := replace(lower(input_string),'ß','ss');
 input_string := replace(lower(input_string),'ä','ae');
 input_string := replace(lower(input_string),'ö','oe');
 input_string := replace(lower(input_string),'ü','ue');
else
 input_string := replace(lower(input_string),'ss','ß');
 input_string := replace(lower(input_string),'ae','ä');
 input_string := replace(lower(input_string),'oe','ö');
 input_string := replace(lower(input_string),'ue','ü');
end if;
return input_string;
END;
$$;

create function adddays(inter interval, days numeric) returns integer
LANGUAGE plpgsql
AS $$
BEGIN
RETURN ( EXTRACT( EPOCH FROM ( inter ) ) / 86400 ) + days;
END;
$$;

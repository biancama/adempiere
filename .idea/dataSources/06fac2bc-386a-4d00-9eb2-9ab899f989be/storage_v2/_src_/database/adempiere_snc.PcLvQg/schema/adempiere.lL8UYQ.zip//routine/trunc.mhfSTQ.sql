create function trunc(datetime timestamp with time zone) returns timestamp with time zone
LANGUAGE plpgsql
AS $$
BEGIN
	RETURN CAST(datetime AS DATE);
END;
$$;

create function nextbusinessday(p_date timestamp with time zone, p_ad_client_id numeric) returns timestamp with time zone
LANGUAGE plpgsql
AS $$
DECLARE
v_nextDate date := trunc(p_Date);
v_offset numeric := 0;
v_Saturday numeric := TO_CHAR(TO_DATE('2000-01-01', 'YYYY-MM-DD'), 'D');
v_Sunday numeric := (case when v_Saturday = 7 then 1 else v_Saturday + 1 end);
v_isHoliday boolean := true;
nbd C_NonBusinessDay%ROWTYPE;
begin
v_isHoliday := true;
loop
SELECT CASE TO_CHAR(v_nextDate,'D')::numeric 
WHEN v_Saturday THEN 2
WHEN v_Sunday THEN 1
ELSE 0
END INTO v_offset;
v_nextDate := v_nextDate + v_offset::integer;
v_isHoliday := false;
FOR nbd IN SELECT * 
FROM C_NonBusinessDay 
WHERE AD_Client_ID=p_AD_Client_ID and IsActive ='Y' and Date1 >= v_nextDate
ORDER BY Date1
LOOP
exit when v_nextDate <> trunc(nbd.Date1);
v_nextDate := v_nextDate + 1;
v_isHoliday := true;
end loop;
exit when v_isHoliday=false;
end loop;
--
return v_nextDate::timestamp with time zone;
end;
$$;

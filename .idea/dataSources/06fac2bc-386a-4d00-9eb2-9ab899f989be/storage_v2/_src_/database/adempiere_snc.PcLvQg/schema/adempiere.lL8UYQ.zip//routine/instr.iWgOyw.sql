create function instr(character varying, character varying) returns integer
IMMUTABLE
LANGUAGE plpgsql
AS $$
DECLARE
    pos integer;
BEGIN
    pos:= instr($1, $2, 1);
    RETURN pos;
END;
$$;

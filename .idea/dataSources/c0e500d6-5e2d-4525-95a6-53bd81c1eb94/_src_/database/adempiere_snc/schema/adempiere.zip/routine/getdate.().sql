create function getdate() returns timestamp with time zone
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN now();
END;
$$;

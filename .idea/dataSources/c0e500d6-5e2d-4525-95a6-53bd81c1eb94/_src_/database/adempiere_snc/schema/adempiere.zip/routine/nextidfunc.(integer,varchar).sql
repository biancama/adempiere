create function nextidfunc(p_ad_sequence_id integer, p_system character varying) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
          o_NextIDFunc INTEGER;
	  dummy INTEGER;
BEGIN
    o_NextIDFunc := nextid(p_AD_Sequence_ID, p_System);
    RETURN o_NextIDFunc;
END;
$$;

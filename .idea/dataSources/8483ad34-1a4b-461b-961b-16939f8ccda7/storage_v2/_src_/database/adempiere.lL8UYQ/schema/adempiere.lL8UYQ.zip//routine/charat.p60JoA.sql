CREATE FUNCTION charat(character varying, integer)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
BEGIN
 RETURN SUBSTR($1, $2, 1);
 END;
$$;


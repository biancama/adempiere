CREATE FUNCTION unaccent_string(p_text text)
  RETURNS text
LANGUAGE plpgsql
AS $$
BEGIN
	return unaccent_string(p_text, 1);
END;
$$;


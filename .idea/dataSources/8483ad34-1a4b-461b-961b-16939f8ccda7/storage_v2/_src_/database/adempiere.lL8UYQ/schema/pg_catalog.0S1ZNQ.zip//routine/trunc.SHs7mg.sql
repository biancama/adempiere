CREATE FUNCTION trunc(numeric)
  RETURNS numeric
IMMUTABLE
STRICT
COST 1
LANGUAGE SQL
AS $$
select pg_catalog.trunc($1,0)
$$;


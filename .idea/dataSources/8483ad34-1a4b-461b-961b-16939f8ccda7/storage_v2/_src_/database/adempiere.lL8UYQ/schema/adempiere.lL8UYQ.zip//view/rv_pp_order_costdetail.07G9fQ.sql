CREATE VIEW rv_pp_order_costdetail AS
  SELECT o.ad_client_id,
    o.ad_org_id,
    obl.pp_order_id,
    obl.m_product_id,
    oc.m_costtype_id,
    oc.m_costelement_id,
    oc.c_acctschema_id,
        CASE
            WHEN (obl.isqtypercentage = 'Y'::bpchar) THEN obl.qtybatch
            ELSE obl.qtybom
        END AS qty,
    obl.qtyrequired,
    oc.currentcostprice,
    oc.currentcostpricell,
    (obl.qtyrequired * oc.currentcostprice) AS expectedcost,
    (obl.qtyrequired * oc.currentcostpricell) AS expectedcostll,
    abs(COALESCE(( SELECT sum(cd.qty) AS sum
           FROM (m_costdetail cd
             JOIN pp_cost_collector cc ON (((cd.pp_cost_collector_id = cc.pp_cost_collector_id) AND (cd.m_product_id = cc.m_product_id))))
          WHERE ((((((cc.pp_order_id = o.pp_order_id) AND (cd.m_product_id = obl.m_product_id)) AND (cd.m_costtype_id = oc.m_costtype_id)) AND (cd.m_costelement_id = oc.m_costelement_id)) AND (cd.c_acctschema_id = oc.c_acctschema_id)) AND ((cc.costcollectortype)::text = '110'::text))), (0)::numeric)) AS cumulatedqty,
    abs(COALESCE(( SELECT sum(cd.amt) AS sum
           FROM (m_costdetail cd
             JOIN pp_cost_collector cc ON (((cd.pp_cost_collector_id = cc.pp_cost_collector_id) AND (cd.m_product_id = cc.m_product_id))))
          WHERE ((((((cc.pp_order_id = o.pp_order_id) AND (cd.m_product_id = obl.m_product_id)) AND (cd.m_costtype_id = oc.m_costtype_id)) AND (cd.m_costelement_id = oc.m_costelement_id)) AND (cd.c_acctschema_id = oc.c_acctschema_id)) AND ((cc.costcollectortype)::text = '110'::text))), (0)::numeric)) AS cumulatedamt,
    abs(COALESCE(( SELECT sum(cd.amtll) AS sum
           FROM (m_costdetail cd
             JOIN pp_cost_collector cc ON (((cd.pp_cost_collector_id = cc.pp_cost_collector_id) AND (cd.m_product_id = cc.m_product_id))))
          WHERE ((((((cc.pp_order_id = o.pp_order_id) AND (cd.m_product_id = obl.m_product_id)) AND (cd.m_costtype_id = oc.m_costtype_id)) AND (cd.m_costelement_id = oc.m_costelement_id)) AND (cd.c_acctschema_id = oc.c_acctschema_id)) AND ((cc.costcollectortype)::text = '110'::text))), (0)::numeric)) AS cumulatedamtll,
    abs(COALESCE(( SELECT sum((cd.amt + cd.amtll)) AS sum
           FROM (m_costdetail cd
             JOIN pp_cost_collector cc ON (((cd.pp_cost_collector_id = cc.pp_cost_collector_id) AND (cd.m_product_id = cc.m_product_id))))
          WHERE ((((((cc.pp_order_id = o.pp_order_id) AND (cd.m_product_id = obl.m_product_id)) AND (cd.m_costtype_id = oc.m_costtype_id)) AND (cd.m_costelement_id = oc.m_costelement_id)) AND (cd.c_acctschema_id = oc.c_acctschema_id)) AND ((cc.costcollectortype)::text = '120'::text))), (0)::numeric)) AS usagevariance,
    abs(COALESCE(( SELECT sum(cd.amtll) AS sum
           FROM (m_costdetail cd
             JOIN pp_cost_collector cc ON (((cd.pp_cost_collector_id = cc.pp_cost_collector_id) AND (cd.m_product_id = cc.m_product_id))))
          WHERE ((((((cc.pp_order_id = o.pp_order_id) AND (cd.m_product_id = obl.m_product_id)) AND (cd.m_costtype_id = oc.m_costtype_id)) AND (cd.m_costelement_id = oc.m_costelement_id)) AND (cd.c_acctschema_id = oc.c_acctschema_id)) AND ((cc.costcollectortype)::text = '130'::text))), (0)::numeric)) AS methodchangevariance,
    abs(COALESCE(( SELECT sum((cd.amt + cd.amtll)) AS sum
           FROM (m_costdetail cd
             JOIN pp_cost_collector cc ON (((cd.pp_cost_collector_id = cc.pp_cost_collector_id) AND (cd.m_product_id = cc.m_product_id))))
          WHERE ((((((cc.pp_order_id = o.pp_order_id) AND (cd.m_product_id = obl.m_product_id)) AND (cd.m_costtype_id = oc.m_costtype_id)) AND (cd.m_costelement_id = oc.m_costelement_id)) AND (cd.c_acctschema_id = oc.c_acctschema_id)) AND ((cc.costcollectortype)::text = '140'::text))), (0)::numeric)) AS ratevariance,
    abs(COALESCE(( SELECT sum((cd.amt + cd.amtll)) AS sum
           FROM (m_costdetail cd
             JOIN pp_cost_collector cc ON (((cd.pp_cost_collector_id = cc.pp_cost_collector_id) AND (cd.m_product_id = cc.m_product_id))))
          WHERE ((((((cc.pp_order_id = o.pp_order_id) AND (cd.m_product_id = obl.m_product_id)) AND (cd.m_costtype_id = oc.m_costtype_id)) AND (cd.m_costelement_id = oc.m_costelement_id)) AND (cd.c_acctschema_id = oc.c_acctschema_id)) AND ((cc.costcollectortype)::text = '150'::text))), (0)::numeric)) AS mixvariance,
    abs(COALESCE(( SELECT sum(cd.amt) AS sum
           FROM (m_costdetail cd
             JOIN pp_cost_collector cc ON (((cd.pp_cost_collector_id = cc.pp_cost_collector_id) AND (cd.m_product_id = cc.m_product_id))))
          WHERE (((((cc.pp_order_id = o.pp_order_id) AND (cd.m_product_id = obl.m_product_id)) AND (cd.m_costtype_id = oc.m_costtype_id)) AND (cd.m_costelement_id = oc.m_costelement_id)) AND (cd.c_acctschema_id = oc.c_acctschema_id))), (0)::numeric)) AS amt,
    abs(COALESCE(( SELECT sum(cd.amtll) AS sum
           FROM (m_costdetail cd
             JOIN pp_cost_collector cc ON (((cd.pp_cost_collector_id = cc.pp_cost_collector_id) AND (cd.m_product_id = cc.m_product_id))))
          WHERE (((((cc.pp_order_id = o.pp_order_id) AND (cd.m_product_id = obl.m_product_id)) AND (cd.m_costtype_id = oc.m_costtype_id)) AND (cd.m_costelement_id = oc.m_costelement_id)) AND (cd.c_acctschema_id = oc.c_acctschema_id))), (0)::numeric)) AS amtll
   FROM ((pp_order_bomline obl
     JOIN pp_order o ON ((obl.pp_order_id = o.pp_order_id)))
     LEFT JOIN pp_order_cost oc ON (((o.pp_order_id = oc.pp_order_id) AND (obl.m_product_id = oc.m_product_id))));


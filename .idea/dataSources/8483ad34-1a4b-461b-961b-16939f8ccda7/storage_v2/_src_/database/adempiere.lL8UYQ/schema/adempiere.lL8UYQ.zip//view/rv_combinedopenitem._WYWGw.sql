CREATE VIEW rv_combinedopenitem AS
  SELECT i.ad_org_id,
    i.ad_client_id,
    i.documentno,
    i.c_invoice_id,
    NULL::numeric AS c_payment_id,
    i.c_order_id,
    i.c_bpartner_id,
    i.issotrx,
    i.dateinvoiced,
    i.dateacct,
    p.netdays,
    paymenttermduedate(i.c_paymentterm_id, (i.dateinvoiced)::timestamp with time zone) AS duedate,
    paymenttermduedays(i.c_paymentterm_id, (i.dateinvoiced)::timestamp with time zone, getdate()) AS daysdue,
    adddays((i.dateinvoiced)::timestamp with time zone, p.discountdays) AS discountdate,
    round(((i.grandtotal * p.discount) / (100)::numeric), 2) AS discountamt,
    i.grandtotal,
    i.c_currency_id,
    i.c_conversiontype_id,
    i.c_paymentterm_id,
    i.ispayschedulevalid,
    NULL::numeric AS c_invoicepayschedule_id,
    i.invoicecollectiontype,
    i.c_campaign_id,
    i.c_project_id,
    i.c_activity_id
   FROM (rv_c_invoice i
     JOIN c_paymentterm p ON ((i.c_paymentterm_id = p.c_paymentterm_id)))
  WHERE (((i.ispayschedulevalid <> 'Y'::bpchar) OR (NOT (EXISTS ( SELECT 1
           FROM c_invoicepayschedule ps
          WHERE (ps.c_invoice_id = i.c_invoice_id))))) AND (i.docstatus <> ALL (ARRAY['DR'::bpchar, 'IP'::bpchar, 'VO'::bpchar, 'RE'::bpchar])))
UNION ALL
 SELECT i.ad_org_id,
    i.ad_client_id,
    i.documentno,
    i.c_invoice_id,
    NULL::numeric AS c_payment_id,
    i.c_order_id,
    i.c_bpartner_id,
    i.issotrx,
    i.dateinvoiced,
    i.dateacct,
    daysbetween((ips.duedate)::timestamp with time zone, (i.dateinvoiced)::timestamp with time zone) AS netdays,
    ips.duedate,
    daysbetween(getdate(), (ips.duedate)::timestamp with time zone) AS daysdue,
    ips.discountdate,
    ips.discountamt,
    ips.dueamt AS grandtotal,
    i.c_currency_id,
    i.c_conversiontype_id,
    i.c_paymentterm_id,
    i.ispayschedulevalid,
    ips.c_invoicepayschedule_id,
    i.invoicecollectiontype,
    i.c_campaign_id,
    i.c_project_id,
    i.c_activity_id
   FROM (rv_c_invoice i
     JOIN c_invoicepayschedule ips ON ((i.c_invoice_id = ips.c_invoice_id)))
  WHERE (((i.ispayschedulevalid = 'Y'::bpchar) AND (i.docstatus <> ALL (ARRAY['DR'::bpchar, 'IP'::bpchar, 'VO'::bpchar, 'RE'::bpchar]))) AND (ips.isvalid = 'Y'::bpchar))
UNION ALL
 SELECT p.ad_org_id,
    p.ad_client_id,
    p.documentno,
    NULL::numeric AS c_invoice_id,
    p.c_payment_id,
    NULL::numeric AS c_order_id,
    p.c_bpartner_id,
    p.isreceipt AS issotrx,
    p.datetrx AS dateinvoiced,
    p.dateacct,
    0 AS netdays,
    p.datetrx AS duedate,
    0 AS daysdue,
    NULL::timestamp without time zone AS discountdate,
    0 AS discountamt,
    (p.payamt * ((-1))::numeric) AS grandtotal,
    p.c_currency_id,
    p.c_conversiontype_id,
    NULL::numeric AS c_paymentterm_id,
    NULL::bpchar AS ispayschedulevalid,
    NULL::numeric AS c_invoicepayschedule_id,
    NULL::bpchar AS invoicecollectiontype,
    p.c_campaign_id,
    p.c_project_id,
    p.c_activity_id
   FROM c_payment p
  WHERE (p.docstatus <> ALL (ARRAY['DR'::bpchar, 'IP'::bpchar, 'VO'::bpchar, 'RE'::bpchar]));


CREATE FUNCTION getdate()
  RETURNS timestamp with time zone
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN now();
END;
$$;


CREATE VIEW rv_click_month AS
  SELECT cc.ad_client_id,
    cc.ad_org_id,
    cc.name,
    cc.description,
    cc.targeturl,
    cc.c_bpartner_id,
    firstof((c.created)::timestamp with time zone, 'MM'::character varying) AS created,
    count(*) AS counter
   FROM (w_clickcount cc
     JOIN w_click c ON ((cc.w_clickcount_id = c.w_clickcount_id)))
  WHERE (cc.isactive = 'Y'::bpchar)
  GROUP BY cc.ad_client_id, cc.ad_org_id, cc.name, cc.description, cc.targeturl, cc.c_bpartner_id, firstof((c.created)::timestamp with time zone, 'MM'::character varying);


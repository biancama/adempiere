CREATE FUNCTION instr(character varying, character varying)
  RETURNS integer
IMMUTABLE
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
    pos integer;
BEGIN
    pos:= instr($1, $2, 1);
    RETURN pos;
END;
$$;


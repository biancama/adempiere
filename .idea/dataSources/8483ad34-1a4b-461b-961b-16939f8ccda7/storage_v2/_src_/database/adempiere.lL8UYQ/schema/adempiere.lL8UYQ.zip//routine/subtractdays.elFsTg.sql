CREATE FUNCTION subtractdays(day timestamp with time zone, days numeric)
  RETURNS date
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN addDays(day,(days * -1));
END;
$$;


CREATE FUNCTION subtractdays(inter interval, days numeric)
  RETURNS integer
LANGUAGE plpgsql
AS $$
BEGIN
RETURN ( EXTRACT( EPOCH FROM ( inter ) ) / 86400 ) - days;
END;
$$;


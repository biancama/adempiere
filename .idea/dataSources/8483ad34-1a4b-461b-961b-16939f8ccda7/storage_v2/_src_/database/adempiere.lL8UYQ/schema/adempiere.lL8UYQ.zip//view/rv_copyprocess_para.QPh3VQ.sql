CREATE VIEW rv_copyprocess_para AS
  SELECT c.ad_client_id,
    c.ad_org_id,
    c.created,
    c.createdby,
    c.updated,
    c.updatedby,
    c.isactive,
    c.ad_element_id,
    c.columnname,
    c.ad_reference_id,
    c.ismandatory,
    'N'::text AS isrange,
    c.defaultvalue,
    NULL::character varying AS defaultvalue2,
    rv.ad_reportview_id,
    'N'::text AS copyfromprocess,
    NULL::numeric AS ad_process_id,
    NULL::numeric AS ad_process_para_id,
    c.ad_column_id
   FROM ((ad_reportview rv
     JOIN ad_table t ON ((t.ad_table_id = rv.ad_table_id)))
     JOIN ad_column c ON ((c.ad_table_id = t.ad_table_id)))
UNION ALL
 SELECT pp.ad_client_id,
    pp.ad_org_id,
    pp.created,
    pp.createdby,
    pp.updated,
    pp.updatedby,
    pp.isactive,
    pp.ad_element_id,
    pp.columnname,
    pp.ad_reference_id,
    pp.ismandatory,
    'N'::text AS isrange,
    pp.defaultvalue,
    pp.defaultvalue2,
    NULL::numeric AS ad_reportview_id,
    'Y'::text AS copyfromprocess,
    p.ad_process_id,
    pp.ad_process_para_id,
    NULL::numeric AS ad_column_id
   FROM (ad_process p
     JOIN ad_process_para pp ON ((pp.ad_process_id = p.ad_process_id)));


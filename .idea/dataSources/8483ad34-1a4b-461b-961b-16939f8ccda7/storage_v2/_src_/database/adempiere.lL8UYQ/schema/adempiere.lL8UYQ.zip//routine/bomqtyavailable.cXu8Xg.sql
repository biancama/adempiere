CREATE FUNCTION bomqtyavailable(product_id numeric, warehouse_id numeric, locator_id numeric)
  RETURNS numeric
LANGUAGE plpgsql
AS $$
BEGIN
	RETURN bomQtyOnHand(Product_ID, Warehouse_ID, Locator_ID) - bomQtyReserved(Product_ID, Warehouse_ID, Locator_ID);
END;
$$;


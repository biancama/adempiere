CREATE FUNCTION trunc(datetime timestamp with time zone)
  RETURNS timestamp with time zone
LANGUAGE plpgsql
AS $$
BEGIN
	RETURN CAST(datetime AS DATE);
END;
$$;


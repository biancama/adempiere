CREATE FUNCTION trunc(i interval)
  RETURNS integer
LANGUAGE plpgsql
AS $$
BEGIN
	RETURN EXTRACT(DAY FROM i);
END;
$$;


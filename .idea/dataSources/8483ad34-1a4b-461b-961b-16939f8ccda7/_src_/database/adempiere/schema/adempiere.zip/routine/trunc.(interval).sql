create function trunc(i interval) returns integer
LANGUAGE plpgsql
AS $$
BEGIN
	RETURN EXTRACT(DAY FROM i);
END;
$$;

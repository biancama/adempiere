create function unaccent_string(p_text text) returns text
LANGUAGE plpgsql
AS $$
BEGIN
	return unaccent_string(p_text, 1);
END;
$$;

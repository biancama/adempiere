create function charat(character varying, integer) returns character varying
LANGUAGE plpgsql
AS $$
BEGIN
 RETURN SUBSTR($1, $2, 1);
 END;
$$;

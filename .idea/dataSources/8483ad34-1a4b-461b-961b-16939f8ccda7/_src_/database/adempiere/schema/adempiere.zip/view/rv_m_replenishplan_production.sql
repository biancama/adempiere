CREATE VIEW rv_m_replenishplan_production AS SELECT mrl.ad_client_id,
    mrl.ad_org_id,
    mrl.m_replenishplan_id,
    p.m_product_id,
    pd.m_production_id,
    pd.productionqty,
    pd.datepromised,
    pd.movementdate,
    pd.isactive,
    p.m_product_category_id,
    trunc(c.currentcostprice, 6) AS currentcostprice,
    (trunc(c.currentcostprice, 6) * pd.productionqty) AS currentcostvalue
   FROM (((m_replenishplanline mrl
     JOIN m_production pd ON ((pd.m_production_id = mrl.m_production_id)))
     JOIN m_product p ON ((p.m_product_id = pd.m_product_id)))
     LEFT JOIN m_cost c ON ((c.m_product_id = p.m_product_id)))
  WHERE (((mrl.recordtype)::text = 'Planned Production'::text) AND (c.m_costelement_id = ( SELECT m_costelement.m_costelement_id
           FROM m_costelement
          WHERE (((m_costelement.ad_client_id = p.ad_client_id) AND (m_costelement.costingmethod = 'S'::bpchar)) AND (m_costelement.costelementtype = 'M'::bpchar)))))
  ORDER BY pd.m_production_id;
